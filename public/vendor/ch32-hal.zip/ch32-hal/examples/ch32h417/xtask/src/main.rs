//! Build, flash and merge driver for the CH32H417 dual-core examples.
//!
//! H417 is one chip with two cores that cannot share a Cargo target: the V3F
//! (control core, hart 0) is a 32-bit `imafc` core, while the V5F (hart 1) is
//! `imafbc` with its own memory map part-way into the same flash. They are
//! therefore two crates under this directory, and this xtask is the entry
//! point that knows how to build them, flash them in the right order, and
//! merge them into a single image.
//!
//! ```text
//! cargo xtask build [--example NAME] [--v3f-only]
//! cargo xtask flash --example NAME [--v3f-only] [--no-build]
//! cargo xtask run   --example NAME [--v3f-only] [--no-build]
//! cargo xtask merge --example NAME [--out DIR]
//! cargo xtask report
//! ```
//!
//! # The two kinds of example
//!
//! Reset only starts the V3F: the V5F sits until the V3F writes its wake
//! register, so a V5F-only image has no entry point and cannot run by itself.
//! Examples therefore come in exactly two shapes, and the xtask derives which
//! one from the files that exist:
//!
//! * **v3f-only** — `v3f/src/bin/NAME.rs` alone.
//! * **dual-core** — `v3f/src/bin/NAME.rs` *and* `v5f/src/bin/NAME.rs`; the
//!   V3F half brings the chip up and wakes hart 1.
//!
//! A `v5f/src/bin/NAME.rs` without its V3F half is rejected.
//!
//! Every `cargo`/`wlink`/`probe-rs` invocation runs with the working directory
//! set to the core's crate: that is what makes the crate's `.cargo/config.toml`
//! (custom target JSON and `build-std`) apply. Running `cargo --manifest-path v3f/…`
//! from here would silently fall back to the host target.

use std::path::{Path, PathBuf};
use std::process::{exit, Command};
use std::time::{Duration, Instant};
use std::{env, fs, thread};

use ch32h417_ipc::protocols as ipc;

/// Bytes an erased flash byte reads as, used to pad the merged image.
const ERASED: u8 = 0xFF;

/// Where the chip's flash starts in the address space; `Core::flash_base` is
/// relative to it.
const CHIP_FLASH_BASE: u64 = 0x0800_0000;

/// How many times a flash is retried before giving up.
const VERIFY_ATTEMPTS: u32 = 3;

/// Deadline for a write, generous enough that a healthy one is never cut short.
const FLASH_TIMEOUT: Duration = Duration::from_secs(60);

/// How long to let the link settle after a mode switch or chip reset.
const RECOVER_SETTLE: Duration = Duration::from_secs(2);

/// Deadline for a request that only moves registers or a few bytes.
const QUICK_TIMEOUT: Duration = Duration::from_secs(30);

/// `probe-rs --chip` value for this board.
const PROBE_RS_CHIP: &str = "CH32H417QEU6";

/// Which tool programs the flash.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Flasher {
    /// `wlink`, WCH's own tool. Picks the first attached probe by itself, but a
    /// write can report success without reaching the flash, so images other
    /// than the last are read back and retried.
    Wlink,
    /// `probe-rs`, which verifies every image after writing and resets the chip
    /// only when asked. It cannot choose between two attached probes, so
    /// `PROBE_RS_PROBE` has to name one in that case.
    ProbeRs,
}

/// One core of the chip.
///
/// `flash_base` / `flash_limit` mirror that core's `memory.x` (the V3F owns the
/// first 64K and the V5F image starts at 0x00010000, the same split the WCH
/// CSDK uses in `Ld/V3F/Link_v3f.ld` and `Ld/V5F/Link_v5f.ld`).
struct Core {
    /// Directory name below this one.
    name: &'static str,
    /// Rust target of the custom JSON in that directory.
    target: &'static str,
    /// Offset of this core's image inside the chip's flash.
    flash_base: u64,
    /// Flash bytes the image may occupy.
    flash_limit: u64,
}

/// In flash order: the V3F image is written first with `--no-run`, then the V5F
/// image resets and runs the chip, by which time both images are in place.
const CORES: [Core; 2] = [
    Core {
        name: "v3f",
        target: "riscv32imafc-unknown-none-elf",
        flash_base: 0x0000_0000,
        flash_limit: 64 * 1024,
    },
    Core {
        name: "v5f",
        target: "riscv32imafbc-unknown-none-elf",
        flash_base: 0x0001_0000,
        flash_limit: 960 * 1024 - 64 * 1024,
    },
];

const USAGE: &str = "\
usage: cargo xtask <command> [options]

commands:
  build [--example NAME] [--features A,B] [--dual-core | --jump-v5f]
                                            build one example (or all)
  flash --example NAME [--features A,B] [--dual-core | --jump-v5f] [--no-build]
        [--flasher wlink | probe-rs]        build, then flash and reset
  run   --example NAME [--dual-core | --jump-v5f] [--no-build]
                                            flash and view the V3F defmt RTT console
  merge --example NAME [--dual-core | --jump-v5f] [--out DIR]
                                            merge the images into .bin + .hex
  report --example NAME                    read that example's mailbox back

flashing:
  --flasher wlink        (default) WCH's tool; picks the first probe, but the
                         final image cannot be read back, so it is unverified
  --flasher probe-rs     verifies every image and resets once at the end
  WLINK_PROBE=VID:PID:SERIAL (or a wlink index) pins every wlink call to one
                         probe; PROBE_RS_PROBE names the probe for probe-rs, and
                         both tools accept the same string, so set both or point
                         one at the other's value

features:
  --features A,B         extra crate features on top of the ones the example
                         needs (`pioc_ws2812`'s IO0 pin, for instance)

what gets programmed:
  (default)      the boot core alone (same as --v3f-only); the V5F region keeps
                 whatever image it already holds
  --dual-core    both halves of the named example, V3F first
  --jump-v5f     the generic jump-only firmware (`launcher`) on the boot core
                 and, when --example names one, that example's V5F half

Reset only ever starts the V3F, so there is no V5F-only mode; see the module
docs.";

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let Some((command, rest)) = args.split_first() else {
        fail(USAGE);
    };

    let opts = Options::parse(rest);
    match command.as_str() {
        "build" => build(&opts),
        "flash" => flash(&opts, false),
        "run" => flash(&opts, true),
        "merge" => merge(&opts),
        "report" => report(&opts),
        "help" | "--help" | "-h" => println!("{USAGE}"),
        other => fail(&format!("unknown command `{other}`\n\n{USAGE}")),
    }
}

/// Parsed command line.
struct Options {
    example: Option<String>,
    layout: Layout,
    no_build: bool,
    out: Option<PathBuf>,
    flasher: Flasher,
    /// Extra crate features, appended to the per-example defaults.
    features: Vec<String>,
}

impl Options {
    fn parse(args: &[String]) -> Options {
        let mut opts = Options {
            example: None,
            layout: Layout::V3fOnly,
            no_build: false,
            out: None,
            flasher: Flasher::Wlink,
            features: Vec::new(),
        };
        let mut args = args.iter();
        while let Some(arg) = args.next() {
            match arg.as_str() {
                "--example" => opts.example = args.next().cloned(),
                // The default, accepted so a script can say what it means.
                "--v3f-only" => opts.layout = Layout::V3fOnly,
                "--dual-core" => opts.layout = Layout::DualCore,
                "--jump-v5f" => opts.layout = Layout::JumpV5f,
                "--out" => opts.out = args.next().map(PathBuf::from),
                "--no-build" => opts.no_build = true,
                "--features" => {
                    let list = args
                        .next()
                        .unwrap_or_else(|| fail("`--features` needs a comma-separated list"));
                    opts.features
                        .extend(list.split(',').filter(|name| !name.is_empty()).map(String::from));
                }
                "--flasher" => {
                    let tool = args.next().unwrap_or_else(|| fail("`--flasher` needs a tool"));
                    opts.flasher = match tool.as_str() {
                        "wlink" => Flasher::Wlink,
                        "probe-rs" => Flasher::ProbeRs,
                        other => fail(&format!("unknown flasher `{other}` (wlink | probe-rs)")),
                    };
                }
                other => fail(&format!("unknown option `{other}`\n\n{USAGE}")),
            }
        }
        opts
    }

    /// Cores to act on, each with the image that supplies it.
    ///
    /// With no `--example` this is every core, which is what `build` wants; the
    /// commands that need an image of their own reject the empty example.
    fn jobs(&self) -> Vec<Job> {
        let job = |core: &'static Core, example: &str| Job {
            core,
            example: example.to_string(),
        };
        let boot = core_named(BOOT_CORE);
        let second = core_named(SECOND_CORE);

        match (self.example.as_deref(), self.layout) {
            (None, Layout::JumpV5f) => vec![job(boot, JUMP_FIRMWARE)],
            (None, _) => CORES
                .iter()
                .map(|core| Job {
                    core,
                    example: String::new(),
                })
                .collect(),
            // The boot core alone; the V5F region keeps whatever it holds.
            (Some(example), Layout::V3fOnly) => {
                require_source(boot, example);
                vec![job(boot, example)]
            }
            (Some(example), Layout::DualCore) => {
                require_source(boot, example);
                require_source(second, example);
                vec![job(boot, example), job(second, example)]
            }
            // The generic jumper on the boot core, the named example on hart 1.
            (Some(example), Layout::JumpV5f) => {
                require_source(second, example);
                vec![job(boot, JUMP_FIRMWARE), job(second, example)]
            }
        }
    }
}

/// What to program.
#[derive(Clone, Copy, PartialEq, Eq)]
enum Layout {
    /// The named example's boot-core half only. The default: the boot core is
    /// what reset starts, and rewriting the V5F payload is opt-in.
    V3fOnly,
    /// Both halves of the named example.
    DualCore,
    /// The generic jump-only firmware on the boot core, plus the named
    /// example's V5F half when an example is given.
    JumpV5f,
}

/// One core to act on, and the example that supplies its image.
struct Job {
    core: &'static Core,
    example: String,
}

/// The core reset starts, and the one that carries the entry point.
const BOOT_CORE: &str = "v3f";

/// The other core, which only ever runs what the boot core hands over to it.
const SECOND_CORE: &str = "v5f";

/// The V3F-only firmware whose whole job is to hand over to hart 1.
const JUMP_FIRMWARE: &str = "launcher";

/// The core with this directory name.
fn core_named(name: &str) -> &'static Core {
    CORES
        .iter()
        .find(|core| core.name == name)
        .expect("core names are fixed")
}

/// Fails unless `core` carries `example`.
fn require_source(core: &Core, example: &str) {
    if !example_source(core, example).exists() {
        fail(&format!(
            "`{example}` has no {}-core half ({} does not exist)",
            core.name,
            example_source(core, example).display()
        ));
    }
}

/// Directory holding `v3f/`, `v5f/`, `xtask/` and `out/`.
fn root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("xtask lives one level below the H417 examples directory")
        .to_path_buf()
}

/// Source file of `example` on `core`, if that core carries it.
fn example_source(core: &Core, example: &str) -> PathBuf {
    root().join(core.name).join("src/bin").join(format!("{example}.rs"))
}

/// Built (release) ELF of `example` on `core`.
fn example_elf(core: &Core, example: &str) -> PathBuf {
    root()
        .join(core.name)
        .join("target")
        .join(core.target)
        .join("release")
        .join(example)
}

/// Probe selector passed to every `wlink` call, if one is configured.
///
/// Without it `wlink` uses whichever WCH-Link it enumerates first, and that
/// order changes when probes are replugged or when one switches between RV and
/// DAP mode — so with more than one probe attached a flash can land on the
/// wrong board. `WLINK_PROBE` (or `PROBE_RS_PROBE`, which `probe-rs` uses for
/// the same purpose) takes an index or `VID:PID:SERIAL`.
fn wlink_selector_args() -> Vec<String> {
    match env::var("WLINK_PROBE").or_else(|_| env::var("PROBE_RS_PROBE")) {
        Ok(selector) if !selector.is_empty() => vec!["-d".to_string(), selector],
        _ => Vec::new(),
    }
}

/// Runs `wlink` with the configured probe selector, from `dir`.
fn run_wlink(args: &[&str], dir: &Path) {
    let selector = wlink_selector_args();
    let mut all: Vec<&str> = selector.iter().map(String::as_str).collect();
    all.extend_from_slice(args);
    run("wlink", &all, dir);
}

/// `run_wlink` with a deadline; see [`run_timed`].
fn run_wlink_timed(args: &[&str], dir: &Path, timeout: Duration) -> bool {
    let selector = wlink_selector_args();
    let mut all: Vec<&str> = selector.iter().map(String::as_str).collect();
    all.extend_from_slice(args);
    run_timed("wlink", &all, dir, timeout)
}

/// Runs a program from `dir`, failing the xtask if it does.
fn run(program: &str, args: &[&str], dir: &Path) {
    println!("  {} {}", program, args.join(" "));
    let status = Command::new(program)
        .args(args)
        .current_dir(dir)
        .status()
        .unwrap_or_else(|e| fail(&format!("failed to run `{program}`: {e}")));
    if !status.success() {
        fail(&format!("`{program}` failed with {status}"));
    }
}

/// Runs `program`, killing it if it outlives `timeout`. Returns success.
///
/// Writes need this: when an earlier program was interrupted the chip's flash
/// controller stays mid-operation, and the next `wlink flash` then waits forever
/// for a ready bit that never arrives. Without a deadline the whole xtask hangs
/// there, so the caller can reset the chip and retry instead.
fn run_timed(program: &str, args: &[&str], dir: &Path, timeout: Duration) -> bool {
    let mut child = match Command::new(program).args(args).current_dir(dir).spawn() {
        Ok(child) => child,
        Err(e) => {
            println!("  failed to run `{program}`: {e}");
            return false;
        }
    };
    let deadline = Instant::now() + timeout;
    loop {
        match child.try_wait() {
            Ok(Some(status)) => return status.success(),
            Ok(None) => {}
            Err(e) => {
                println!("  failed to wait for `{program}`: {e}");
                return false;
            }
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            println!("  `{program}` did not finish within {}s", timeout.as_secs());
            return false;
        }
        thread::sleep(Duration::from_millis(100));
    }
}

/// Escalates between write attempts.
///
/// The one recovery observed reproducibly is simply repeating the write: a
/// request that follows a killed one often hangs once and then works. The
/// stronger steps — reset the chip, then re-cycle the link's protocol mode
/// (RV -> DAP -> RV) — are best-effort: they are cheap and have cleared the few
/// persistent cases, but the evidence is anecdotal (one such "recovery" was
/// really the board being restarted by hand), so they only run after a plain
/// retry has already failed.
fn recover(attempt: u32) {
    if attempt == 1 {
        println!("  retrying ...");
        return;
    }
    println!("  resetting the chip and re-cycling the link mode before the retry ...");
    run_wlink_timed(&["reset", "halt"], &root(), QUICK_TIMEOUT);
    thread::sleep(RECOVER_SETTLE);
    run_wlink_timed(&["mode-switch", "--dap"], &root(), QUICK_TIMEOUT);
    thread::sleep(RECOVER_SETTLE);
    for _ in 0..2 {
        if run_wlink_timed(&["mode-switch", "--rv"], &root(), QUICK_TIMEOUT) {
            break;
        }
        thread::sleep(RECOVER_SETTLE);
    }
    // The link needs a moment in RV mode before it will program again.
    thread::sleep(RECOVER_SETTLE);
}

fn build(opts: &Options) {
    // The boot core owns the shared region and brings the chip up, so it is built
    // first; nothing it produces feeds the other core's build. The mailbox address
    // is fixed by the linker scripts (see `ch32h417_ipc::MAILBOX_ADDR`), so there
    // is no layout file to hand across.
    for job in &opts.jobs() {
        build_core(job, &opts.features);
    }
    if opts.example.is_some() {
        println!("built: {}", describe(&opts.jobs()));
    }
}

/// Builds one core's image.
fn build_core(job: &Job, extra_features: &[String]) {
    let dir = root().join(job.core.name);
    // `build_core` owns the strings its arguments borrow from, so they are
    // bound before `args` and outlive it.
    let features = {
        let default = match job.example.as_str() {
            "embassy_systick" | "can_async_check" | "usbss_host_link_check" | "pioc_ws2812" | "pioc_text" => {
                Some("embassy")
            }
            "eth_internal" | "eth_bench" => Some("eth"),
            "usbhs_cdc" | "usbfs_cdc" | "usbss_cdc" | "usbss_bench" => Some("usb"),
            _ => None,
        };
        // `--features` comes on top: `pioc_ws2812` needs it to pick the IO0
        // pin, because the vendor default is not routed out on every board.
        default
            .into_iter()
            .map(String::from)
            .chain(extra_features.iter().cloned())
            .collect::<Vec<_>>()
            .join(",")
    };
    let bin = job.example.clone();
    let mut args = vec!["build", "--release"];
    if !bin.is_empty() {
        args.extend(["--bin", &bin]);
    }
    if !features.is_empty() {
        args.extend(["--features", &features]);
    }
    println!("building {} ...", job.core.name);
    run("cargo", &args, &dir);
}

/// Warns when `example`'s boot-core image places its mailbox somewhere other
/// than [`ch32h417_ipc::MAILBOX_ADDR`].
///
/// The address is fixed by the linker scripts, so this only catches the two
/// having drifted apart. It says nothing when the image was never built, or when
/// the example places no mailbox.
fn check_mailbox_address(example: &str) {
    let elf = example_elf(core_named(BOOT_CORE), example);
    let Some((address, _)) = elf.exists().then(|| mailbox_symbol(&elf)).flatten() else {
        return;
    };
    if address as usize != ch32h417_ipc::MAILBOX_ADDR {
        println!(
            "note: `{example}` places its mailbox at {address:#010x}, not {:#010x} — the linker \n\
             \x20     scripts and `ch32h417_ipc::MAILBOX_ADDR` have drifted apart",
            ch32h417_ipc::MAILBOX_ADDR
        );
    }
}

/// `(address, size)` of the `MAILBOX` symbol in `elf`, read straight out of the
/// ELF symbol table instead of shelling out to `llvm-nm` (CI installs no
/// `llvm-tools-preview`).
fn mailbox_symbol(elf: &Path) -> Option<(u32, u32)> {
    let data = fs::read(elf).ok()?;
    // ELF32, little endian, then its section header table.
    if data.len() < 0x34 || &data[0..4] != b"\x7fELF" || data[4] != 1 || data[5] != 1 {
        return None;
    }
    let u16_at = |o: usize| u16::from_le_bytes([data[o], data[o + 1]]) as usize;
    let u32_at = |o: usize| u32::from_le_bytes([data[o], data[o + 1], data[o + 2], data[o + 3]]);
    let shoff = u32_at(0x20) as usize;
    let shentsize = u16_at(0x2e);
    let shnum = u16_at(0x30);

    // SHT_SYMTAB; its sh_link names the string table.
    let mut symtab = None;
    for i in 0..shnum {
        let sh = shoff + i * shentsize;
        if u32_at(sh + 4) == 2 {
            symtab = Some(sh);
            break;
        }
    }
    let symtab = symtab?;
    let sym_off = u32_at(symtab + 0x10) as usize;
    let sym_size = u32_at(symtab + 0x14) as usize;
    let strtab = shoff + u32_at(symtab + 0x18) as usize * shentsize;
    let str_off = u32_at(strtab + 0x10) as usize;

    for i in 0..sym_size / 16 {
        let sym = sym_off + i * 16;
        let name_at = str_off + u32_at(sym) as usize;
        let name = data[name_at..].split(|byte| *byte == 0).next().unwrap_or_default();
        if name == b"MAILBOX" {
            return Some((u32_at(sym + 4), u32_at(sym + 8)));
        }
    }
    None
}

/// Build and flash the selected images. `run` also opens the V3F RTT stream.
/// Multi-core flashing verifies the non-final image before starting the chip.
fn flash(opts: &Options, watch: bool) {
    let jobs = opts.jobs();
    if jobs.iter().any(|job| job.example.is_empty()) {
        fail(&format!(
            "`{}` needs --example (or `--jump-v5f` on its own)\n\n{USAGE}",
            if watch { "run" } else { "flash" }
        ));
    }
    if !opts.no_build {
        build(opts);
    }
    if opts.layout == Layout::JumpV5f {
        if let Some(example) = &opts.example {
            if example_source(core_named(BOOT_CORE), example).exists() {
                println!(
                    "note: --jump-v5f replaces `{example}`'s own V3F half with the jumper,\n\
                     \x20     so whatever that half printed or drove will not happen. Use\n\
                     \x20     --dual-core when the example's V3F half does real work\n\
                     \x20     (e.g. `sdi_cpuid`'s V3F reporting)."
                );
            }
        }
    }
    // PROBE_RS_PROBE selects a probe if more than one is connected.
    if watch && jobs.len() == 1 {
        let elf = example_elf(jobs[0].core, &jobs[0].example);
        run(
            "probe-rs",
            &[
                "run",
                "--chip",
                PROBE_RS_CHIP,
                "--scan-region",
                "ram",
                elf.to_str().expect("utf-8 path"),
            ],
            &root(),
        );
        return;
    }
    match opts.flasher {
        Flasher::Wlink => {
            // The last write resets and runs the chip, so it cannot be read
            // back; every earlier one is. `--flasher probe-rs` verifies all of
            // them and resets afterwards instead.
            for (i, job) in jobs.iter().enumerate() {
                let core = job.core;
                let elf = example_elf(core, &job.example);
                println!("flashing {} ({}) ...", core.name, job.example);
                if i + 1 == jobs.len() {
                    run_wlink(&["flash", elf.to_str().expect("utf-8 path")], &root());
                } else {
                    let args = ["flash", "--no-run", elf.to_str().expect("utf-8 path")];
                    program_verified(core, &job.example, &elf, &args, true);
                }
            }
        }
        Flasher::ProbeRs => {
            // `download` does not run the chip, so every image is written and
            // verified first and the single reset at the end starts the boot
            // core with both halves already in place.
            for job in jobs.iter() {
                let elf = example_elf(job.core, &job.example);
                println!("flashing {} ({}) with probe-rs ...", job.core.name, job.example);
                run(
                    "probe-rs",
                    &[
                        "download",
                        "--chip",
                        PROBE_RS_CHIP,
                        "--verify",
                        elf.to_str().expect("utf-8 path"),
                    ],
                    &root(),
                );
            }
            run("probe-rs", &["reset", "--chip", PROBE_RS_CHIP], &root());
        }
    }
    if watch {
        let boot = jobs.iter().find(|job| job.core.name == BOOT_CORE).expect("boot image");
        let elf = example_elf(boot.core, &boot.example);
        println!("attaching to V3F RTT; V5F has a separate buffer");
        run(
            "probe-rs",
            &[
                "attach",
                "--chip",
                PROBE_RS_CHIP,
                "--scan-region",
                "ram",
                elf.to_str().expect("utf-8 path"),
            ],
            &root(),
        );
    }
}

/// Runs `wlink` with `args`, then reads the region back and compares it with the
/// image that was built (`check`). Retries the whole command on mismatch.
///
/// `wlink flash` has been observed to return success while only part of the
/// image — or none of it — reached the flash: the log stops after
/// `Read protected: false` and never prints `Flash done`. Without this check
/// that looks exactly like a firmware bug in the code under test.
fn program_verified(core: &Core, example: &str, elf: &Path, args: &[&str], check: bool) {
    let expected = flatten(elf, core);
    for attempt in 1..=VERIFY_ATTEMPTS {
        let wrote = run_wlink_timed(args, &root(), FLASH_TIMEOUT);
        if wrote && !check {
            return;
        }
        if !wrote {
            recover(attempt);
            continue;
        }
        match read_flash(core, expected.len()) {
            // `wlink dump` rounds its length up to a word, so compare the
            // image-sized prefix rather than the vectors themselves, and treat
            // the bytes the image leaves as erased as don't-care: sections are
            // written individually, so the alignment gaps between them keep
            // whatever the flash held there.
            Some(actual) if actual.len() >= expected.len() => {
                let wrong = expected
                    .iter()
                    .zip(&actual)
                    .filter(|(want, got)| **want != ERASED && want != got)
                    .count();
                if wrong == 0 {
                    println!("  {} verified ({} bytes)", core.name, expected.len());
                    return;
                }
                println!(
                    "  {}: read-back differs in {wrong} of {} bytes on attempt {attempt}",
                    core.name,
                    expected.len()
                );
            }
            Some(_) => println!("  {}: read-back was short on attempt {attempt}", core.name),
            None => println!("  {}: read-back failed on attempt {attempt}", core.name),
        }
        recover(attempt);
    }
    fail(&format!(
        "{}: `{example}` is not in flash after {VERIFY_ATTEMPTS} attempts — \
         the probe returned success but did not program the image",
        core.name
    ));
}

/// Reads `len` bytes of `core`'s image back out of flash, or `None` on failure.
fn read_flash(core: &Core, len: usize) -> Option<Vec<u8>> {
    let tmp = env::temp_dir().join(format!("h417-verify-{}-{}.bin", core.name, std::process::id()));
    let address = format!("{:#010x}", CHIP_FLASH_BASE + core.flash_base);
    let length = len.to_string();
    let ok = run_wlink_timed(
        &["dump", &address, &length, "-o", tmp.to_str()?],
        &root(),
        QUICK_TIMEOUT,
    );
    let bytes = ok.then(|| fs::read(&tmp).ok()).flatten();
    let _ = fs::remove_file(&tmp);
    bytes
}

/// A contiguous payload of the merged image.
struct Segment {
    core: &'static str,
    base: u64,
    bytes: Vec<u8>,
}

fn merge(opts: &Options) {
    let jobs = opts.jobs();
    let boot = jobs
        .iter()
        .find(|job| job.core.name == BOOT_CORE && !job.example.is_empty());
    let second = jobs
        .iter()
        .find(|job| job.core.name == SECOND_CORE && !job.example.is_empty());
    let (Some(boot), Some(second)) = (boot, second) else {
        fail(&format!(
            "merging needs both cores — pass --dual-core, or --jump-v5f with --example\n\n{USAGE}"
        ));
    };

    let segments: Vec<Segment> = [boot, second]
        .into_iter()
        .map(|job| Segment {
            core: job.core.name,
            base: job.core.flash_base,
            bytes: flatten(&example_elf(job.core, &job.example), job.core),
        })
        .collect();
    // The merged file is named after what runs on hart 1, with the jumper called
    // out when the boot core is the generic firmware.
    let name = if boot.example == JUMP_FIRMWARE {
        format!("jump-{}", second.example)
    } else {
        second.example.clone()
    };

    // Assemble the full image: erased flash, with each core's payload at its
    // own offset.
    let end = segments
        .iter()
        .map(|s| s.base + s.bytes.len() as u64)
        .max()
        .expect("at least one segment");
    let mut image = vec![ERASED; end as usize];
    for segment in &segments {
        let at = segment.base as usize;
        image[at..at + segment.bytes.len()].copy_from_slice(&segment.bytes);
    }

    let out_dir = opts.out.clone().unwrap_or_else(|| root().join("out"));
    fs::create_dir_all(&out_dir).unwrap_or_else(|e| fail(&format!("cannot create {}: {e}", out_dir.display())));
    let bin = out_dir.join(format!("{name}.bin"));
    let hex = out_dir.join(format!("{name}.hex"));
    fs::write(&bin, &image).unwrap_or_else(|e| fail(&format!("cannot write {}: {e}", bin.display())));
    fs::write(&hex, intel_hex(&segments)).unwrap_or_else(|e| fail(&format!("cannot write {}: {e}", hex.display())));

    for segment in &segments {
        println!(
            "  {:<4} {:#010x}  {:>7} bytes",
            segment.core,
            segment.base,
            segment.bytes.len()
        );
    }
    println!("merged image: {} ({} bytes)", bin.display(), image.len());
    println!("intel hex:    {}", hex.display());
}

/// Reads the mailbox back and decodes it.
///
/// Read an example's shared-memory report after flashing.

fn report(opts: &Options) {
    let Some(example) = opts.example.as_deref() else {
        fail(&format!("`report` needs --example NAME\n\n{USAGE}"))
    };
    let len = match example {
        "dualcore" => size_of::<ch32h417_ipc::Mailbox<ipc::Dualcore>>(),
        "delay_systick" => size_of::<ch32h417_ipc::Mailbox<ipc::DelaySystick>>(),
        "rcc_delay_check" => size_of::<ch32h417_ipc::Mailbox<ipc::RccDelayCheck>>(),
        "spi_check" => size_of::<ch32h417_ipc::Mailbox<ipc::SpiCheck>>(),
        "can_check" => size_of::<ch32h417_ipc::Mailbox<ipc::CanCheck>>(),
        "timer_check" => size_of::<ch32h417_ipc::Mailbox<ipc::TimerCheck>>(),
        "dma2_check" => size_of::<ch32h417_ipc::Mailbox<ipc::Dma2Check>>(),
        "exti_check" => size_of::<ch32h417_ipc::Mailbox<ipc::ExtiCheck>>(),
        "bus_check" => size_of::<ch32h417_ipc::Mailbox<ipc::BusCheck>>(),
        "esig_check" => size_of::<ch32h417_ipc::Mailbox<ipc::EsigCheck>>(),
        "can_async_check" => size_of::<ch32h417_ipc::Mailbox<ipc::CanAsyncCheck>>(),
        "rtc_check" => size_of::<ch32h417_ipc::Mailbox<ipc::RtcCheck>>(),
        "rtc_hse_check" => size_of::<ch32h417_ipc::Mailbox<ipc::RtcHseCheck>>(),
        "sdio_exfat" | "sdio_fat" | "sdio_check" | "sdio_raw" | "sdio_rawn" | "sdio_inherit" => {
            size_of::<ch32h417_ipc::Mailbox<ipc::SdioCheck>>()
        }
        "rng_check" => size_of::<ch32h417_ipc::Mailbox<ipc::RngCheck>>(),
        "adc_check" => size_of::<ch32h417_ipc::Mailbox<ipc::AdcCheck>>(),
        "dac_check" => size_of::<ch32h417_ipc::Mailbox<ipc::DacCheck>>(),
        "flash_check" => size_of::<ch32h417_ipc::Mailbox<ipc::FlashCheck>>(),
        "embassy_systick" => size_of::<ch32h417_ipc::Mailbox<ipc::EmbassySystick>>(),
        "atomics" => size_of::<ch32h417_ipc::Mailbox<ipc::Atomics>>(),
        "cpuid" => size_of::<ch32h417_ipc::Mailbox<ipc::Cpuid>>(),
        "pingpong" => size_of::<ch32h417_ipc::Mailbox<ipc::Pingpong>>(),
        "sdi_cpuid" => size_of::<ch32h417_ipc::Mailbox<ipc::SdiCpuid>>(),
        "bme280" => size_of::<ch32h417_ipc::Mailbox<ipc::Bme280>>(),
        "launcher" => size_of::<ch32h417_ipc::Mailbox<ipc::Empty>>(),
        other => fail(&format!("{other} publishes nothing `report` knows how to read")),
    };

    check_mailbox_address(example);
    let base = ch32h417_ipc::MAILBOX_ADDR as u64;
    let tmp = env::temp_dir().join(format!("h417-mailbox-{}.bin", std::process::id()));
    let address = format!("{base:#010x}");
    let length = len.to_string();
    let read = run_wlink_timed(
        &["dump", &address, &length, "-o", tmp.to_str().expect("utf-8 path")],
        &root(),
        QUICK_TIMEOUT,
    );
    if !read {
        fail("could not read the mailbox");
    }
    let bytes = fs::read(&tmp).unwrap_or_else(|e| fail(&format!("reading {}: {e}", tmp.display())));
    let _ = fs::remove_file(&tmp);

    let word = |offset: usize| -> u32 {
        u32::from_le_bytes([bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]])
    };

    println!("mailbox @ {base:#010x} ({example})");
    let version = word(core::mem::offset_of!(ch32h417_ipc::Mailbox<ipc::Empty>, layout_version));
    if version != ch32h417_ipc::LAYOUT_VERSION {
        println!(
            "  note: the flashed half reports mailbox layout v{version}, this tool knows v{} — \
             reflash both halves",
            ch32h417_ipc::LAYOUT_VERSION
        );
    }

    /// Print `label` and the word at `field` of `payload`.
    macro_rules! field {
        ($payload:ty, $field:ident, $label:literal) => {
            println!(
                "  {:<18}= {}",
                $label,
                word(core::mem::offset_of!(
                    ch32h417_ipc::Mailbox<$payload>,
                    payload.$field
                ))
            )
        };
    }

    match example {
        "dualcore" => {
            let marker = word(core::mem::offset_of!(
                ch32h417_ipc::Mailbox<ipc::Dualcore>,
                payload.marker
            ));
            println!(
                "  {:<18}= {marker:#010x}{}",
                "marker",
                if marker == ipc::DUALCORE_MARKER {
                    "  (hart 1 ran)"
                } else {
                    ""
                }
            );
            field!(ipc::Dualcore, counter, "counter");
        }
        "delay_systick" => {
            field!(ipc::DelaySystick, v3f_ticks, "v3f ticks");
            field!(ipc::DelaySystick, v5f_ticks, "v5f ticks");
        }
        "rcc_delay_check" => {
            field!(ipc::RccDelayCheck, stage, "stage");
            field!(ipc::RccDelayCheck, failures, "failures");
            field!(ipc::RccDelayCheck, v3f_hz, "v3f Hz");
            field!(ipc::RccDelayCheck, v5f_hz, "v5f Hz");
            field!(ipc::RccDelayCheck, heartbeat, "heartbeat");
        }
        "spi_check" => {
            field!(ipc::SpiCheck, stage, "stage");
            field!(ipc::SpiCheck, failures, "failures");
            field!(ipc::SpiCheck, cases, "cases");
            field!(ipc::SpiCheck, ctlr1, "CTLR1");
            field!(ipc::SpiCheck, hscr, "HSCR");
            field!(ipc::SpiCheck, loopback, "loopback");
        }
        "can_check" => {
            field!(ipc::CanCheck, stage, "stage");
            field!(ipc::CanCheck, failures, "failures");
            field!(ipc::CanCheck, checks, "checks");
            field!(ipc::CanCheck, frames, "CAN1 frames");
            field!(ipc::CanCheck, can2_frames, "CAN2 frames");
            field!(ipc::CanCheck, filter_banks, "filter banks");
            field!(ipc::CanCheck, tx_ok, "tx ok");
            field!(ipc::CanCheck, rx_ok, "rx ok");
            field!(ipc::CanCheck, last_id, "last id");
            field!(ipc::CanCheck, tstatr, "TSTATR");
            field!(ipc::CanCheck, errsr, "ERRSR");
            field!(ipc::CanCheck, pclk1, "PCLK1 Hz");
        }
        "timer_check" => {
            field!(ipc::TimerCheck, stage, "stage");
            field!(ipc::TimerCheck, failures, "failures");
            field!(ipc::TimerCheck, checks, "checks");
            field!(ipc::TimerCheck, timers, "timer classes");
            field!(ipc::TimerCheck, updates, "last update count");
            field!(ipc::TimerCheck, frequency, "last frequency Hz");
            field!(ipc::TimerCheck, wide_arr, "TIM9 ARR");
            field!(ipc::TimerCheck, pclk1, "PCLK1 Hz");
        }
        "dma2_check" => {
            field!(ipc::Dma2Check, stage, "stage");
            field!(ipc::Dma2Check, failures, "failures");
            field!(ipc::Dma2Check, checks, "checks");
            field!(ipc::Dma2Check, matched, "bytes matched");
            field!(ipc::Dma2Check, tcif, "TCIF ch1");
            field!(ipc::Dma2Check, remaining, "remaining");
            field!(ipc::Dma2Check, length, "length");
        }
        "exti_check" => {
            field!(ipc::ExtiCheck, stage, "stage");
            field!(ipc::ExtiCheck, failures, "failures");
            field!(ipc::ExtiCheck, checks, "checks");
            field!(ipc::ExtiCheck, lines, "lines mask");
            field!(ipc::ExtiCheck, rounds, "rounds");
            field!(ipc::ExtiCheck, intfr, "INTFR");
            field!(ipc::ExtiCheck, intenr, "INTENR");
        }
        "bus_check" => {
            field!(ipc::BusCheck, stage, "stage");
            field!(ipc::BusCheck, failures, "failures");
            field!(ipc::BusCheck, checks, "checks");
            field!(ipc::BusCheck, usart_mask, "USART mask");
            field!(ipc::BusCheck, spi_mask, "SPI mask");
            field!(ipc::BusCheck, i2c_mask, "I2C mask");
            field!(ipc::BusCheck, pclk1, "PCLK1 Hz");
        }
        "esig_check" => {
            field!(ipc::EsigCheck, stage, "stage");
            field!(ipc::EsigCheck, failures, "failures");
            field!(ipc::EsigCheck, checks, "checks");
            field!(ipc::EsigCheck, flash_kb, "flash KB");
            field!(ipc::EsigCheck, uid0, "UID word 0");
            field!(ipc::EsigCheck, uid1, "UID word 1");
            field!(ipc::EsigCheck, uid2, "UID word 2");
            field!(ipc::EsigCheck, chip_id, "chip ID");
        }
        "can_async_check" => {
            field!(ipc::CanAsyncCheck, stage, "stage");
            field!(ipc::CanAsyncCheck, failures, "failures");
            field!(ipc::CanAsyncCheck, checks, "checks");
            field!(ipc::CanAsyncCheck, frames, "frames");
            field!(ipc::CanAsyncCheck, tx_ok, "tx ok");
            field!(ipc::CanAsyncCheck, rx_ok, "rx ok");
            field!(ipc::CanAsyncCheck, last_id, "last id");
        }
        "rtc_check" => {
            field!(ipc::RtcCheck, stage, "stage");
            field!(ipc::RtcCheck, failures, "failures");
            field!(ipc::RtcCheck, checks, "checks");
            field!(ipc::RtcCheck, time, "RTC seconds");
            field!(ipc::RtcCheck, seconds, "second interrupts");
            field!(ipc::RtcCheck, alarms, "alarm interrupts");
            field!(ipc::RtcCheck, prescaler, "prescaler");
            field!(ipc::RtcCheck, frequency, "input clock Hz");
            field!(ipc::RtcCheck, lse, "LSE validated");
            field!(ipc::RtcCheck, lse_wait_ms, "LSE wait ms");
            field!(ipc::RtcCheck, rtcsel, "RTCSEL (1=LSE)");
        }
        "rtc_hse_check" => {
            field!(ipc::RtcHseCheck, stage, "stage");
            field!(ipc::RtcHseCheck, failures, "failures");
            field!(ipc::RtcHseCheck, checks, "checks");
            field!(ipc::RtcHseCheck, time, "RTC seconds");
            field!(ipc::RtcHseCheck, prescaler, "prescaler");
            field!(ipc::RtcHseCheck, frequency, "input clock Hz");
        }
        "sdio_exfat" | "sdio_fat" => {
            field!(ipc::SdioCheck, stage, "stage (7 = verified)");
            field!(ipc::SdioCheck, error, "error (0 = none)");
            field!(ipc::SdioCheck, first_word, "test file number");
            field!(ipc::SdioCheck, blocks, "bytes verified");
            field!(ipc::SdioCheck, clock, "reported SDIO clock Hz");
        }
        "sdio_check" | "sdio_raw" | "sdio_rawn" | "sdio_inherit" => {
            field!(ipc::SdioCheck, stage, "stage");
            field!(ipc::SdioCheck, failures, "failures");
            field!(ipc::SdioCheck, checks, "checks");
            field!(ipc::SdioCheck, card, "card");
            field!(ipc::SdioCheck, error, "error");
            field!(ipc::SdioCheck, blocks, "blocks");
            field!(ipc::SdioCheck, clock, "clock");
            field!(ipc::SdioCheck, first_word, "first word");
            field!(ipc::SdioCheck, status, "STA");
            field!(ipc::SdioCheck, hclk, "HCLK");
            field!(ipc::SdioCheck, clkcr, "CLKCR");
            field!(ipc::SdioCheck, cmd0_sta, "CMD0 STA");
            field!(ipc::SdioCheck, cmd8_sta, "CMD8 STA");
            field!(ipc::SdioCheck, resp1, "RESP1");
            field!(ipc::SdioCheck, levels_idle, "levels idle");
            field!(ipc::SdioCheck, levels_cmd8, "levels after CMD8");
            field!(ipc::SdioCheck, cmd55_sta, "CMD55 STA");
            field!(ipc::SdioCheck, resp55, "CMD55 RESP1");
            field!(ipc::SdioCheck, acmd41_sta, "ACMD41 STA");
            field!(ipc::SdioCheck, resp41, "ACMD41 RESP1");
            field!(ipc::SdioCheck, ck_high, "CK high/256");
            field!(ipc::SdioCheck, cmd_edges, "CMD edges");
        }
        "rng_check" => {
            field!(ipc::RngCheck, stage, "stage");
            field!(ipc::RngCheck, failures, "failures");
            field!(ipc::RngCheck, words, "words");
            field!(ipc::RngCheck, checksum, "checksum");
        }
        "adc_check" => {
            field!(ipc::AdcCheck, stage, "stage");
            field!(ipc::AdcCheck, failures, "failures");
            field!(ipc::AdcCheck, pa1, "PA1");
            field!(ipc::AdcCheck, vref, "VREFINT");
            field!(ipc::AdcCheck, temperature, "temperature");
        }
        "dac_check" => {
            field!(ipc::DacCheck, stage, "stage");
            field!(ipc::DacCheck, failures, "failures");
            field!(ipc::DacCheck, dor1, "DOR1");
            field!(ipc::DacCheck, dor2, "DOR2");
        }
        "flash_check" => {
            field!(ipc::FlashCheck, stage, "stage");
            field!(ipc::FlashCheck, failures, "failures");
            field!(ipc::FlashCheck, checks, "checks");
            field!(ipc::FlashCheck, capacity, "capacity");
            field!(ipc::FlashCheck, geometry, "geometry");
            field!(ipc::FlashCheck, erased_word, "erased word");
            field!(ipc::FlashCheck, readback, "readback");
        }
        "embassy_systick" => {
            field!(ipc::EmbassySystick, stage, "stage");
            field!(ipc::EmbassySystick, error_us, "error us");
            field!(ipc::EmbassySystick, ticks, "ticks");
        }
        "atomics" => report_atomics(&word),
        "bme280" => report_bme280(&word),
        "cpuid" => report_cpuid(
            &word,
            core::mem::offset_of!(ch32h417_ipc::Mailbox<ipc::Cpuid>, payload.cpuid),
        ),
        "pingpong" => {
            report_cpuid(
                &word,
                core::mem::offset_of!(ch32h417_ipc::Mailbox<ipc::Pingpong>, payload.cpuid),
            );
            field!(ipc::Pingpong, ping, "ping");
            field!(ipc::Pingpong, pong, "pong");
        }
        "sdi_cpuid" => {
            field!(ipc::SdiCpuid, token, "token");
            field!(ipc::SdiCpuid, ticks, "ticks");
            report_cpuid(
                &word,
                core::mem::offset_of!(ch32h417_ipc::Mailbox<ipc::SdiCpuid>, payload.cpuid),
            );
        }
        "launcher" => {}
        _ => unreachable!(),
    }
}

/// `atomics`: both cores `fetch_add` the same word, so the total is the litmus
/// test for the A extension actually performing the atomics.
fn report_atomics(word: &impl Fn(usize) -> u32) {
    let total = word(core::mem::offset_of!(
        ch32h417_ipc::Mailbox<ipc::Atomics>,
        payload.total
    ));
    let done = word(core::mem::offset_of!(ch32h417_ipc::Mailbox<ipc::Atomics>, payload.done));
    let expected = ipc::CAS_INCREMENTS * 2;
    println!(
        "  total             = {total} (expected {expected}, done mask {done:#x}){}",
        if done & (ipc::CAS_DONE_V3F | ipc::CAS_DONE_V5F) == (ipc::CAS_DONE_V3F | ipc::CAS_DONE_V5F) {
            if total == expected {
                "  OK"
            } else {
                "  LOST UPDATES"
            }
        } else {
            "  (not finished)"
        }
    );
}

/// `bme280`: hart 1 reads the sensor, this prints the last sample it stored.
/// Temperature is 1/100 °C, pressure 1/100 Pa, humidity 1/100 %RH.
fn report_bme280(word: &impl Fn(usize) -> u32) {
    let status = word(core::mem::offset_of!(
        ch32h417_ipc::Mailbox<ipc::Bme280>,
        payload.status
    ));
    let seq = word(core::mem::offset_of!(ch32h417_ipc::Mailbox<ipc::Bme280>, payload.seq));
    let state = match status {
        ipc::BME280_IDLE => "idle",
        ipc::BME280_INIT => "init",
        ipc::BME280_OK => "ok",
        ipc::BME280_BMP => "bmp280",
        ipc::BME280_FAIL => "FAILED",
        _ => "unknown",
    };
    println!("  status            = {status} ({state}), sample {seq}");
    if seq != ipc::BME280_NO_SAMPLE {
        let temperature = word(core::mem::offset_of!(
            ch32h417_ipc::Mailbox<ipc::Bme280>,
            payload.temperature
        ));
        let pressure = word(core::mem::offset_of!(
            ch32h417_ipc::Mailbox<ipc::Bme280>,
            payload.pressure
        ));
        let humidity = word(core::mem::offset_of!(
            ch32h417_ipc::Mailbox<ipc::Bme280>,
            payload.humidity
        ));
        println!(
            "  reading           = {:.2} C, {:.2} hPa, {:.2} %RH",
            temperature as i32 as f32 / 100.0,
            pressure as f32 / 10_000.0,
            humidity as f32 / 100.0
        );
    }
}

/// Hart 1's CPU-ID block, which `cpuid`, `pingpong` and `sdi_cpuid` all carry at
/// different offsets inside their own payload.
fn report_cpuid(word: &impl Fn(usize) -> u32, base: usize) {
    let at = |field| base + field;
    if word(at(core::mem::offset_of!(ipc::CpuidBlock, done))) != ipc::CPUID_DONE {
        println!(
            "  cpuid: no report from hart 1 (magic missing, progress = {})",
            word(at(core::mem::offset_of!(ipc::CpuidBlock, progress)))
        );
        return;
    }
    println!(
        "  cpuid (hart 1)    image build features = {:#04x}",
        word(at(core::mem::offset_of!(ipc::CpuidBlock, buildcfg)))
    );
    let present = word(at(core::mem::offset_of!(ipc::CpuidBlock, present)));
    let values = core::mem::offset_of!(ipc::CpuidBlock, values);
    let mut misa = None;
    for (i, name) in ipc::CPUID_CSR_NAMES.iter().enumerate() {
        let value = word(at(values) + i * 4);
        if present & (1 << i) == 0 {
            println!("    {name:<18}   absent (read faulted)");
            continue;
        }
        println!("    {name:<18} = {value:#010x}");
        if i == ipc::CPUID_MISA_INDEX {
            misa = Some(value);
        }
    }
    if let Some(misa) = misa {
        let letters: String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            .chars()
            .enumerate()
            .filter(|(bit, _)| misa & (1 << bit) != 0)
            .map(|(_, letter)| letter)
            .collect();
        println!("    misa decode        MXL={} extensions={letters}", (misa >> 30) & 3);
    }
}

/// Converts an ELF to a flat binary with `llvm-objcopy`.
///
/// The temporary file is per-process so two xtasks never see each other's
/// half-written image.
fn flatten(elf: &Path, core: &Core) -> Vec<u8> {
    if !elf.exists() {
        fail(&format!(
            "{} is not built — run `cargo xtask build --example {}`",
            elf.display(),
            elf.file_stem().unwrap_or_default().to_string_lossy()
        ));
    }
    let tmp = env::temp_dir().join(format!("h417-{}-{}.bin", core.name, std::process::id()));
    let objcopy = objcopy();
    // `--gap-fill 0xFF` makes the gaps between sections read as erased flash,
    // which is what is actually there: the sections are written individually.
    run(
        &objcopy,
        &[
            "-O",
            "binary",
            "--gap-fill",
            "0xFF",
            elf.to_str().unwrap(),
            tmp.to_str().unwrap(),
        ],
        &root(),
    );
    let bytes = fs::read(&tmp).unwrap_or_else(|e| fail(&format!("cannot read {}: {e}", tmp.display())));
    let _ = fs::remove_file(&tmp);

    if bytes.len() as u64 > core.flash_limit {
        fail(&format!(
            "{}: {} bytes exceeds its {} byte flash region — it would overlap the other image",
            core.name,
            bytes.len(),
            core.flash_limit
        ));
    }
    bytes
}

/// `llvm-objcopy` shipped with the active toolchain, falling back to `PATH`.
fn objcopy() -> String {
    tool("llvm-objcopy")
}

fn tool(name: &str) -> String {
    let output = |args: &[&str]| {
        Command::new("rustc")
            .args(args)
            .output()
            .ok()
            .filter(|o| o.status.success())
            .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
    };
    if let (Some(sysroot), Some(host)) = (output(&["--print", "sysroot"]), output(&["-vV"])) {
        let host = host
            .lines()
            .find_map(|line| line.strip_prefix("host: ").map(str::to_string));
        if let Some(host) = host {
            let path = Path::new(&sysroot)
                .join("lib/rustlib")
                .join(host)
                .join("bin")
                .join(name);
            if path.exists() {
                return path.to_string_lossy().into_owned();
            }
        }
    }
    name.to_string()
}

/// Intel HEX for the payload segments only — the erased padding between the two
/// images would otherwise be tens of thousands of pointless `0xFF` records.
fn intel_hex(segments: &[Segment]) -> String {
    let mut hex = String::new();
    let mut upper = u32::MAX;
    for segment in segments {
        for (i, chunk) in segment.bytes.chunks(16).enumerate() {
            let address = segment.base as u32 + (i * 16) as u32;
            if address >> 16 != upper {
                upper = address >> 16;
                hex.push_str(&record(0x04, 0, &[(upper >> 8) as u8, upper as u8]));
            }
            hex.push_str(&record(0x00, (address & 0xFFFF) as u16, chunk));
        }
    }
    hex.push_str(":00000001FF\n");
    hex
}

/// One Intel HEX record: length, 16-bit address, type, data, checksum.
///
/// The length is derived from `data` — passing it in separately is how the
/// extended-address records ended up claiming zero bytes, which made `wlink`
/// reject the whole file with "payload length does not match record header".
fn record(record_type: u8, address: u16, data: &[u8]) -> String {
    let mut bytes = vec![data.len() as u8, (address >> 8) as u8, address as u8, record_type];
    bytes.extend_from_slice(data);
    let sum = bytes.iter().fold(0u8, |acc, b| acc.wrapping_add(*b));
    let checksum = (!sum).wrapping_add(1);

    let mut line = format!(":{bytes:02X?}");
    line.retain(|c| !matches!(c, '[' | ']' | ' ' | ','));
    format!("{line}{checksum:02X}\n")
}

/// `v3f:cpuid+v5f:cpuid` label for the final build line.
fn describe(jobs: &[Job]) -> String {
    jobs.iter()
        .map(|job| {
            if job.example.is_empty() {
                job.core.name.to_string()
            } else {
                format!("{}:{}", job.core.name, job.example)
            }
        })
        .collect::<Vec<_>>()
        .join("+")
}

fn fail(message: &str) -> ! {
    eprintln!("xtask: {message}");
    exit(1);
}
