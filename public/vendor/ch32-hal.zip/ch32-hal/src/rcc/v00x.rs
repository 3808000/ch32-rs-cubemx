use crate::pac::rcc::vals::{Hpre as HBPrescaler, Pllsrc as PllSource, Sw as Sysclk};
use crate::pac::{AFIO, FLASH, RCC};
use crate::time::Hertz;

pub const HSI_FREQUENCY: Hertz = Hertz(24_000_000);

pub const LSI_FREQUENCY: Hertz = Hertz(128_000);

pub struct Config {
    // won't close hsi
    // pub hsi: bool,
    pub hse: Option<super::Hse>,
    pub sys: Sysclk,

    pub pll_src: PllSource,

    pub hb_pre: HBPrescaler,
}

impl Config {
    pub const SYSCLK_FREQ_24MHZ_HSI: Config = Config {
        hse: None,
        sys: Sysclk::HSI,
        pll_src: PllSource::HSI,
        hb_pre: HBPrescaler::DIV1,
    };

    pub const SYSCLK_FREQ_48MHZ_HSI: Config = Config {
        hse: None,
        sys: Sysclk::PLL,
        pll_src: PllSource::HSI,
        hb_pre: HBPrescaler::DIV1,
    };

    pub const SYSCLK_FREQ_24MHZ_HSE: Config = Config {
        hse: Some(super::Hse {
            freq: Hertz(24_000_000),
            mode: super::HseMode::Oscillator,
        }),
        sys: Sysclk::HSE,
        pll_src: PllSource::HSE,
        hb_pre: HBPrescaler::DIV1,
    };

    pub const SYSCLK_FREQ_48MHZ_HSE: Config = Config {
        hse: Some(super::Hse {
            freq: Hertz(24_000_000),
            mode: super::HseMode::Oscillator,
        }),
        sys: Sysclk::PLL,
        pll_src: PllSource::HSE,
        hb_pre: HBPrescaler::DIV1,
    };
}

impl Default for Config {
    fn default() -> Self {
        Self {
            // hsi: true,
            hse: None,
            sys: Sysclk::HSI,
            pll_src: PllSource::HSI,
            hb_pre: HBPrescaler::DIV3,
        }
    }
}

#[allow(unused_variables)]
pub(crate) unsafe fn init(config: Config) {
    if config.sys == Sysclk::HSE || (config.sys == Sysclk::PLL && config.pll_src == PllSource::HSE) {
        // enable HSE pins
        RCC.pb2pcenr().modify(|w| w.set_afioen(true));
        AFIO.pcfr1().modify(|w| w.set_pa1pa2_rm(true));

        // enable HSE
        RCC.ctlr().modify(|w| {
            w.set_hsebyp(config.hse.unwrap().mode == super::HseMode::Bypass);
            w.set_hseon(true);
        });
        while !RCC.ctlr().read().hserdy() {}
    }

    let sysclk = match config.sys {
        Sysclk::HSI => {
            // HSI default enabled
            HSI_FREQUENCY.0
        }
        Sysclk::HSE => {
            // enable HSE
            RCC.cfgr0().modify(|w| w.set_sw(Sysclk::HSE));
            while RCC.cfgr0().read().sws() != Sysclk::HSE {}
            config.hse.unwrap().freq.0
        }
        Sysclk::PLL => {
            RCC.cfgr0().modify(|w| w.set_pllsrc(config.pll_src));
            RCC.ctlr().modify(|w| w.set_pllon(true));
            while !RCC.ctlr().read().pllrdy() {}

            RCC.cfgr0().modify(|w| w.set_sw(Sysclk::PLL));
            while RCC.cfgr0().read().sws() != Sysclk::PLL {}

            // MUL2 is the only option, always *2
            match config.pll_src {
                PllSource::HSI => HSI_FREQUENCY.0 * 2,
                PllSource::HSE => config.hse.unwrap().freq.0 * 2,
            }
        }
        _ => unreachable!(),
    };

    if sysclk > 24_000_000 {
        FLASH.actlr().modify(|w| w.set_latency(2));
    } else if sysclk > 15_000_000 {
        FLASH.actlr().modify(|w| w.set_latency(1));
    }

    RCC.cfgr0().modify(|w| {
        w.set_hpre(config.hb_pre);
    });

    let hclk = match config.hb_pre {
        HBPrescaler::DIV1 => sysclk,
        HBPrescaler::DIV2 => sysclk / 2,
        HBPrescaler::DIV3 => sysclk / 3,
        HBPrescaler::DIV4 => sysclk / 4,
        HBPrescaler::DIV5 => sysclk / 5,
        HBPrescaler::DIV6 => sysclk / 6,
        HBPrescaler::DIV7 => sysclk / 7,
        HBPrescaler::DIV8 => sysclk / 8,
        HBPrescaler::DIV16 => sysclk / 16,
        HBPrescaler::DIV32 => sysclk / 32,
        HBPrescaler::DIV64 => sysclk / 64,
        HBPrescaler::DIV128 => sysclk / 128,
        HBPrescaler::DIV256 => sysclk / 256,
        _ => panic!(),
    };

    refresh_clocks(config.hse.map(|h| h.freq));
}

pub(crate) unsafe fn refresh_clocks(hse: Option<Hertz>) {
    super::set_clocks(clocks_from_registers(hse));
}

fn clocks_from_registers(hse: Option<Hertz>) -> super::Clocks {
    use crate::pac::rcc::vals::Sw as Sysclk;

    let cfgr = RCC.cfgr0().read();
    let sysclk = match cfgr.sws() {
        Sysclk::HSI => HSI_FREQUENCY.0,
        Sysclk::HSE => hse.expect("RCC: HSE frequency required").0,
        Sysclk::PLL => match cfgr.pllsrc() {
            PllSource::HSI => HSI_FREQUENCY.0 * 2,
            PllSource::HSE => hse.expect("RCC: HSE frequency required").0 * 2,
        },
        _ => HSI_FREQUENCY.0,
    };
    let hclk = hclk_hz(sysclk, cfgr.hpre());
    super::Clocks {
        sysclk: Hertz(sysclk),
        hclk: Hertz(hclk),
        pclk1: Hertz(hclk),
        pclk2: Hertz(hclk),
        pclk1_tim: Hertz(sysclk),
        pclk2_tim: Hertz(sysclk),
    }
}

fn hclk_hz(sysclk: u32, hpre: HBPrescaler) -> u32 {
    match hpre {
        HBPrescaler::DIV1 => sysclk,
        HBPrescaler::DIV2 => sysclk / 2,
        HBPrescaler::DIV3 => sysclk / 3,
        HBPrescaler::DIV4 => sysclk / 4,
        HBPrescaler::DIV5 => sysclk / 5,
        HBPrescaler::DIV6 => sysclk / 6,
        HBPrescaler::DIV7 => sysclk / 7,
        HBPrescaler::DIV8 => sysclk / 8,
        HBPrescaler::DIV16 => sysclk / 16,
        HBPrescaler::DIV32 => sysclk / 32,
        HBPrescaler::DIV64 => sysclk / 64,
        HBPrescaler::DIV128 => sysclk / 128,
        HBPrescaler::DIV256 => sysclk / 256,
        _ => sysclk,
    }
}
