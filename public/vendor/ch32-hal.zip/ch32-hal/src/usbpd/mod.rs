//! USBPD, USB Power Delivery
//!
//! Design:
//!
//! - CC Pins:
//! - UsbPdPhy: USBPD PHY layer
//! - UsbPdSniffer: USBPD Sniffer based on PHY layer, no transmit support
//! - [ ] UsbPdSink: USBPD Sink layer
//! - [ ] UsbPdSource: USBPD Source layer

use core::future::poll_fn;
use core::marker::PhantomData;
use core::sync::atomic::{AtomicBool, Ordering};
use core::task::Poll;

use embassy_sync::waitqueue::AtomicWaker;
use pac::InterruptNumber;

use crate::gpio::Pull;
use crate::mode::{Async, Blocking, Mode};
use crate::pac::usbpd::vals;
use crate::{interrupt, pac, Peri, PeripheralType, RccPeripheral};

#[derive(Debug)]
pub enum Error {
    Rejected,
    Timeout,
    CCNotConnected,
    NotSupported,
    HardReset,
    /// PHY reported a buffer/DMA error; the current transfer must be considered failed.
    BufferError,
    /// Unexpected message type
    Protocol(u8),
    MaxRetry,
}

#[derive(Debug, PartialEq, Eq)]
pub enum Sop {
    Sop = 0b00_00_00_00,
    SopPrime = 0b00_00_01_01,
    SopDoublePrime = 0b00_01_00_01,
    HardReset = 0b10_10_10_01,
}

/// Interrupt handler.
pub struct InterruptHandler<T: Instance> {
    _phantom: PhantomData<T>,
}

impl<T: Instance> interrupt::typelevel::Handler<T::Interrupt> for InterruptHandler<T> {
    unsafe fn on_interrupt() {
        let usbpd = T::REGS;

        let status = usbpd.status().read();

        if status.if_tx_end() {
            T::REGS.config().modify(|w| w.set_ie_tx_end(false));
        }

        if status.if_rx_act() {
            T::REGS.control().modify(|w| w.set_bmc_start(false)); // stop
            T::REGS.config().modify(|w| w.set_ie_rx_act(false));
        }

        if status.if_rx_reset() {
            T::REGS.config().modify(|w| w.set_ie_rx_reset(false));
        }

        if status.buf_err() {
            // No dedicated IE bit; gated by PD_DMA_EN. Latch and drop IEs
            // so the poller observes the error and returns.
            T::state().buf_err.store(true, Ordering::Release);
            T::REGS.config().modify(|w| {
                w.set_ie_rx_act(false);
                w.set_ie_rx_reset(false);
                w.set_ie_tx_end(false);
            });
        }

        T::REGS.status().write_value(status);

        // Wake the task to clear and re-enabled interrupts.
        T::state().waker.wake();
    }
}

#[repr(align(4))]
struct UsbPdMsg {
    pub data: [u8; 30],
}
impl UsbPdMsg {
    fn new() -> Self {
        Self { data: [0u8; 30] }
    }

    fn to_slice(&self) -> &[u8] {
        &self.data
    }

    fn address(&self) -> u16 {
        self.data.as_ptr() as u16
    }

    fn mut_address(&mut self) -> u16 {
        self.data.as_mut_ptr() as u16
    }
}

pub struct UsbPdPhy<'d, T: Instance, M: Mode> {
    _marker: PhantomData<(&'d mut T, M)>,
    cc1: vals::CcSel,
    cc2: vals::CcSel,
    buffer: UsbPdMsg,
}

impl<'d, T: Instance + PeripheralType> UsbPdPhy<'d, T, Async> {
    pub fn new_async(
        peri: Peri<'d, T>,
        cc1: Peri<'d, impl CcPin<T>>,
        cc2: Peri<'d, impl CcPin<T>>,
        _irq: impl interrupt::typelevel::Binding<T::Interrupt, InterruptHandler<T>> + 'd,
    ) -> UsbPdPhy<'d, T, Async> {
        unsafe {
            use crate::interrupt::typelevel::Interrupt;
            T::Interrupt::enable();
        };

        Self::new_inner(peri, cc1, cc2)
    }

    fn enable_rx_interrupt(&mut self) {
        // Clear stale BUF_ERR (HW W1C, then latch) before re-arming IEs.
        T::REGS.status().write(|w| w.set_buf_err(true));
        T::state().buf_err.store(false, Ordering::Release);
        T::REGS.config().modify(|w| {
            w.set_ie_rx_act(true); // Receive completion interrupt enable
            w.set_ie_rx_reset(true); // Receive reset interrupt enable
            w.set_ie_tx_end(false); // End-of-transmit interrupt disable
        });
    }

    fn enable_tx_interrupt(&mut self) {
        // Clear stale BUF_ERR (HW W1C, then latch) before re-arming IEs.
        T::REGS.status().write(|w| w.set_buf_err(true));
        T::state().buf_err.store(false, Ordering::Release);
        T::REGS.config().modify(|w| {
            w.set_ie_rx_act(false); // Receive completion interrupt disable
            w.set_ie_rx_reset(false); // Receive reset interrupt disable
            w.set_ie_tx_end(true); // End-of-transmit interrupt enable
        });
    }

    /// Receives a PD message into the provided buffer.
    ///
    /// Returns the SOP and number of received bytes, or an error.
    pub async fn receive(&mut self, buf: &mut [u8]) -> Result<(Sop, usize), Error> {
        self.enable_rx_interrupt();
        self.prepare_receive();

        poll_fn(|cx| {
            T::state().waker.register(cx.waker());

            if T::state().buf_err.load(Ordering::Acquire) {
                return Poll::Ready(Err(Error::BufferError));
            }

            if !T::REGS.config().read().ie_rx_reset() {
                return Poll::Ready(Err(Error::HardReset));
            }

            if !T::REGS.config().read().ie_rx_act() {
                Poll::Ready(Ok(()))
            } else {
                Poll::Pending
            }
        })
        .await?;
        self.post_receive(buf)
    }

    pub async fn transmit(&mut self, buf: &[u8]) -> Result<(), Error> {
        self.enable_tx_interrupt();
        self.transmit_inner(Sop::Sop, buf);
        let result = self.wait_for_tx_complete().await;

        T::port_cc_reg(vals::CcSel::CC1).modify(|w| w.set_cc_lve(false));
        T::port_cc_reg(vals::CcSel::CC2).modify(|w| w.set_cc_lve(false));

        result
    }

    /// Transmit a hard reset.
    pub async fn transmit_hardreset(&mut self) -> Result<(), Error> {
        self.enable_tx_interrupt();
        self.transmit_inner(Sop::HardReset, &[]);
        let result = self.wait_for_tx_complete().await;

        T::port_cc_reg(vals::CcSel::CC1).modify(|w| w.set_cc_lve(false));
        T::port_cc_reg(vals::CcSel::CC2).modify(|w| w.set_cc_lve(false));

        result
    }

    async fn wait_for_tx_complete(&mut self) -> Result<(), Error> {
        poll_fn(|cx| {
            T::state().waker.register(cx.waker());

            if T::state().buf_err.load(Ordering::Acquire) {
                return Poll::Ready(Err(Error::BufferError));
            }

            if !T::REGS.config().read().ie_tx_end() {
                return Poll::Ready(Ok(()));
            }
            Poll::Pending
        })
        .await
    }
}

impl<'d, T: Instance + PeripheralType> UsbPdPhy<'d, T, Blocking> {
    pub fn new_blocking(
        peri: Peri<'d, T>,
        cc1: Peri<'d, impl CcPin<T>>,
        cc2: Peri<'d, impl CcPin<T>>,
    ) -> UsbPdPhy<'d, T, Blocking> {
        Self::new_inner(peri, cc1, cc2)
    }

    pub fn receive(&mut self, buf: &mut [u8]) -> Result<(Sop, usize), Error> {
        unsafe {
            qingke::pfic::disable_interrupt(interrupt::USBPD.number() as _);
        }
        self.prepare_receive();

        let outcome = loop {
            let status = T::REGS.status().read();
            if status.buf_err() {
                break Err(Error::BufferError);
            }
            if status.if_rx_act() {
                break Ok(());
            }
            if status.if_rx_reset() {
                break Err(Error::HardReset);
            }
            #[cfg(feature = "embassy")]
            embassy_futures::yield_now();
        };

        unsafe {
            qingke::pfic::enable_interrupt(interrupt::USBPD.number() as _);
        }
        outcome?;
        self.post_receive(buf)
    }

    pub fn transmit(&mut self, buf: &[u8]) -> Result<(), Error> {
        unsafe {
            qingke::pfic::disable_interrupt(interrupt::USBPD.number() as _);
        }
        self.transmit_inner(Sop::Sop, buf);

        let result = loop {
            let status = T::REGS.status().read();
            if status.buf_err() {
                break Err(Error::BufferError);
            }
            if status.if_tx_end() {
                break Ok(());
            }
            #[cfg(feature = "embassy")]
            embassy_futures::yield_now();
        };

        T::port_cc_reg(vals::CcSel::CC1).modify(|w| w.set_cc_lve(false));
        T::port_cc_reg(vals::CcSel::CC2).modify(|w| w.set_cc_lve(false));

        unsafe {
            qingke::pfic::enable_interrupt(interrupt::USBPD.number() as _);
        }

        result
    }
}

impl<'d, T: Instance + PeripheralType, M: Mode> UsbPdPhy<'d, T, M> {
    /// Create a new USB-PD driver.
    fn new_inner(_peri: Peri<'d, T>, cc1: Peri<'d, impl CcPin<T>>, cc2: Peri<'d, impl CcPin<T>>) -> Self {
        assert!(cc1.port_sel() != cc2.port_sel(), "CC1 and CC2 should be different");

        #[allow(unused)]
        let afio = crate::pac::AFIO;

        T::enable_and_reset();

        cc1.set_as_input(Pull::None);
        cc2.set_as_input(Pull::None);

        // PD 引脚 PC14/PC15 高阈值输入模式
        // PD 收发器 PHY 上拉限幅配置位: USBPD_PHY_V33
        #[cfg(ch32x0)]
        afio.ctlr().modify(|w| {
            w.set_usbpd_in_hvt(true);
            w.set_usbpd_phy_v33(true);
        });
        #[cfg(ch32l1)]
        afio.cr().modify(|w| {
            // PD pin PB6/PD7 High threshold input mode.
            w.set_usbpd_in_hvt(true);
        });

        T::REGS.config().write(|w| {
            w.set_pd_dma_en(true);
            //    w.set_pd_filt_en(true);
            //  w.set_pd_rst_en(true);
        });
        T::REGS.status().write(|w| {
            w.set_if_tx_end(true);
            w.set_if_rx_reset(true);
            w.set_if_rx_act(true);
            w.set_if_rx_byte(true);
            w.set_if_rx_bit(true);
            w.set_buf_err(true);
        });

        // pd_phy_reset

        T::port_cc_reg(cc1.port_sel()).write(|w| w.set_cc_ce(vals::PortCcCe::V0_66));
        T::port_cc_reg(cc2.port_sel()).write(|w| w.set_cc_ce(vals::PortCcCe::V0_66));

        let this = Self {
            _marker: PhantomData,
            cc1: cc1.port_sel(),
            cc2: cc2.port_sel(),
            buffer: UsbPdMsg::new(),
        };

        this
    }

    pub fn reset(&mut self) -> Result<(), Error> {
        T::enable_and_reset();

        T::REGS.config().write(|w| {
            w.set_pd_dma_en(true);
            //    w.set_pd_filt_en(true);
        });
        T::REGS.status().write(|w| {
            w.set_if_tx_end(true);
            w.set_if_rx_reset(true);
            w.set_if_rx_act(true);
            w.set_if_rx_byte(true);
            w.set_if_rx_bit(true);
            w.set_buf_err(true);
        });

        T::port_cc_reg(self.cc1).modify(|w| w.set_cc_lve(false));
        T::port_cc_reg(self.cc2).modify(|w| w.set_cc_lve(false));

        self.detect_cc()?;

        // pd_phy_reset
        T::port_cc_reg(self.cc1).write(|w| w.set_cc_ce(vals::PortCcCe::V0_66));
        T::port_cc_reg(self.cc2).write(|w| w.set_cc_ce(vals::PortCcCe::V0_66));

        Ok(())
    }

    pub fn detect_cc(&self) -> Result<(), Error> {
        // CH32X035 has no internal CC pull down support
        // The detection voltage is 0.22V, sufficient to detect the default power(500mA/900mA)

        T::port_cc_reg(self.cc1).modify(|w| w.set_cc_ce(vals::PortCcCe::V0_22));
        crate::delay::Delay.delay_us(2);

        if T::port_cc_reg(self.cc1).read().pa_cc_ai() {
            // CC1 is connected
            T::REGS.config().modify(|w| w.set_cc_sel(vals::CcSel::CC1));
            Ok(())
        } else {
            T::port_cc_reg(self.cc2).modify(|w| w.set_cc_ce(vals::PortCcCe::V0_22));
            crate::delay::Delay.delay_us(2);

            if T::port_cc_reg(self.cc2).read().pa_cc_ai() {
                // CC2 is connected
                T::REGS.config().modify(|w| w.set_cc_sel(vals::CcSel::CC2));
                Ok(())
            } else {
                Err(Error::CCNotConnected)
            }
        }
    }

    /// Prepares the PHY for receiving a PD message into a buffer.
    fn prepare_receive(&mut self) {
        // set rx mode
        T::REGS.config().modify(|w| w.set_pd_all_clr(true));
        T::REGS.config().modify(|w| w.set_pd_all_clr(false));

        T::REGS.dma().write_value(self.buffer.mut_address());

        T::REGS.control().modify(|w| w.set_pd_tx_en(false)); // RX
        T::REGS
            .bmc_clk_cnt()
            .modify(|w| w.set_bmc_clk_cnt(calc_bmc_clk_for_rx()));

        T::REGS.control().modify(|w| w.set_bmc_start(true));
    }

    /// Decodes the received PD message and returns a tuple (Sop, length) or an error.
    fn post_receive(&self, buf: &mut [u8]) -> Result<(Sop, usize), Error> {
        if T::REGS.status().read().if_rx_reset() {
            return Err(Error::HardReset);
        }
        let byte_count = T::REGS.bmc_byte_cnt().read().bmc_byte_cnt() as usize;
        let byte_count = byte_count.saturating_sub(4); // Strip the 4-byte CRC
        let byte_count = byte_count.min(buf.len()).min(30); // Cap to buffer size and our internal buffer size
        buf[..byte_count].copy_from_slice(&self.buffer.to_slice()[..byte_count]);
        match T::REGS.status().read().bmc_aux() {
            vals::BmcAux::SOP0 => Ok((Sop::Sop, byte_count)),
            vals::BmcAux::SOP1 => Ok((Sop::SopPrime, byte_count)),
            vals::BmcAux::SOP2 => Ok((Sop::SopDoublePrime, byte_count)),
            _ => Err(Error::Rejected),
        }
    }

    fn transmit_inner(&mut self, sop: Sop, buf: &[u8]) {
        T::port_cc_reg(T::REGS.config().read().cc_sel()).modify(|w| w.set_cc_lve(true));

        T::REGS
            .bmc_clk_cnt()
            .write(|w| w.set_bmc_clk_cnt(calc_bmc_clk_for_tx()));

        if buf.is_empty() {
            T::REGS.dma().write_value(0);
        } else {
            // We use our own buffer to ensure it is 4-byte aligned, as required by the hardware.
            let len = buf.len().min(30);
            self.buffer.data[..len].copy_from_slice(&buf[..len]);
            T::REGS.dma().write_value(self.buffer.address());
        }

        T::REGS.tx_sel().write(|w| w.0 = sop as u8);

        T::REGS.bmc_tx_sz().write(|w| w.set_bmc_tx_sz(buf.len() as _));
        T::REGS.control().modify(|w| w.set_pd_tx_en(true)); // TX

        T::REGS.status().write(|w| {
            w.set_if_tx_end(true);
            w.set_if_rx_reset(true);
            w.set_if_rx_act(true);
            w.set_if_rx_byte(true);
            w.set_if_rx_bit(true);
            w.set_buf_err(true);
        });

        T::REGS.control().modify(|w| w.set_bmc_start(true));
    }
}

struct State {
    waker: AtomicWaker,
    // Inverted logic for a default state of 0 so that the data goes into the .bss section.
    drop_not_ready: AtomicBool,
    // Set by the ISR on BUF_ERR; cleared at the start of each transfer.
    buf_err: AtomicBool,
}

impl State {
    pub const fn new() -> Self {
        Self {
            waker: AtomicWaker::new(),
            drop_not_ready: AtomicBool::new(false),
            buf_err: AtomicBool::new(false),
        }
    }
}

trait SealedInstance {
    const REGS: crate::pac::usbpd::Usbpd;

    fn state() -> &'static State;
}

#[allow(private_bounds)]
pub trait Instance: SealedInstance + RccPeripheral {
    type Interrupt: crate::interrupt::typelevel::Interrupt;

    #[allow(dead_code)]
    fn port_cc_reg(cc: vals::CcSel) -> pac::common::Reg<pac::usbpd::regs::PortCc, pac::common::RW> {
        match cc {
            vals::CcSel::CC1 => Self::REGS.port_cc1(),
            vals::CcSel::CC2 => Self::REGS.port_cc2(),
            #[cfg(ch641)]
            vals::CcSel::CC3 => Self::REGS.port_cc3(),
            #[allow(unreachable_patterns)]
            _ => panic!("Invalid CC"),
        }
    }
}

// catch GLOBAL irq
foreach_interrupt!(
    ($inst:ident, usbpd, USBPD, GLOBAL, $irq:ident) => {
        impl SealedInstance for crate::peripherals::$inst {
            const REGS: crate::pac::usbpd::Usbpd = crate::pac::$inst;

            fn state() -> &'static State {
                static STATE: State = State::new();
                &STATE
            }
        }

        impl Instance for crate::peripherals::$inst {
            type Interrupt = crate::interrupt::typelevel::$irq;
        }
    };
);

pub trait CcPin<T: Instance>: crate::gpio::Pin {
    fn port_sel(&self) -> pac::usbpd::vals::CcSel;
}

#[cfg(ch32x0)]
mod _cc_pin_ch32x0 {
    use super::*;

    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PC14 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC1
        }
    }
    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PC15 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC2
        }
    }
}

#[cfg(ch32l1)]
mod _cc_pin_ch32l1 {
    use super::*;

    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PB6 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC1
        }
    }
    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PB7 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC2
        }
    }
}

#[cfg(ch641)]
mod _cc_pin_ch641 {
    use super::*;

    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PB0 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC1
        }
    }
    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PB1 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC2
        }
    }
    impl CcPin<crate::peripherals::USBPD> for crate::peripherals::PB9 {
        #[inline(always)]
        fn port_sel(&self) -> pac::usbpd::vals::CcSel {
            pac::usbpd::vals::CcSel::CC3
        }
    }
}

#[inline]
fn calc_bmc_clk_for_tx() -> u16 {
    (crate::rcc::clocks().hclk.0 / 1_000_000 * 80 / 48 - 1) as u16
}

#[inline]
fn calc_bmc_clk_for_rx() -> u16 {
    (crate::rcc::clocks().hclk.0 / 1_000_000 * 120 / 48 - 1) as u16
}
