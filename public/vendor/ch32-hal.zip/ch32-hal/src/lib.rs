#![no_std]
#![allow(static_mut_refs, unexpected_cfgs)]

use core::future::Future;

pub use ch32_metapac as pac;
pub(crate) use embassy_hal_internal::{impl_peripheral, peripherals_definition, peripherals_struct};
pub use embassy_hal_internal::{Peri, PeripheralType};
#[cfg(feature = "rt")]
pub use qingke_rt::{entry, interrupt};

// This must go FIRST so that all the other modules see its macros.
include!(concat!(env!("OUT_DIR"), "/_macros.rs"));

pub(crate) mod internal;

mod macros;

pub mod time;
/// Operating modes for peripherals.
pub mod mode {
    trait SealedMode {}

    /// Operating mode for a peripheral.
    #[allow(private_bounds)]
    pub trait Mode: SealedMode {}

    macro_rules! impl_mode {
        ($name:ident) => {
            impl SealedMode for $name {}
            impl Mode for $name {}
        };
    }

    /// Blocking mode.
    pub struct Blocking;
    /// Async mode.
    pub struct Async;
    /// NB mode.
    pub struct NonBlocking;

    impl_mode!(Blocking);
    impl_mode!(Async);
    impl_mode!(NonBlocking);
}

// Without an Embassy time driver, hardware waits have no deadline and may
// block indefinitely if the peripheral or bus does not make progress.
#[derive(Copy, Clone)]
struct Timeout {
    #[cfg(feature = "embassy")]
    deadline: embassy_time::Instant,
}

#[allow(dead_code)]
impl Timeout {
    #[inline]
    fn check(self) -> Option<()> {
        #[cfg(feature = "embassy")]
        if embassy_time::Instant::now() > self.deadline {
            return None;
        }

        Some(())
    }

    #[inline]
    fn with<R>(self, fut: impl Future<Output = Option<R>>) -> impl Future<Output = Option<R>> {
        #[cfg(feature = "embassy")]
        {
            use futures::FutureExt;

            embassy_futures::select::select(embassy_time::Timer::at(self.deadline), fut).map(|r| match r {
                embassy_futures::select::Either::First(_) => None,
                embassy_futures::select::Either::Second(r) => r,
            })
        }

        #[cfg(not(feature = "embassy"))]
        fut
    }
}

pub mod rcc;

pub mod debug;
pub mod prelude;

mod peripheral;
pub use peripheral::{RccPeripheral, RemapPeripheral};

// #[cfg(not(ch32v0))]
mod interrupt_ext;

pub use crate::_generated::{peripherals, Peripherals};

#[cfg(not(time_driver_systick))]
pub mod delay;
pub mod dma;

// ADC / DAC drivers are written against the V3-family register layout
// (`pac::adc::vals::SampleTime`, `pac::dac::vals::TrigSel`, ...). On H4 and
// V4x7 these `vals` submodules don't exist because chiptool only emits them
// for fields that carry enum types, so those families use the V4x7 driver,
// which defines its own sample-time enum. H4's block keeps the V4x7 layout
// apart from the regular-data split; the driver covers both.
#[cfg(all(adc, not(any(ch32h4, ch32v4))))]
pub mod adc;
#[cfg(adc_v4x7)]
#[path = "adc/v4x7.rs"]
pub mod adc;
#[cfg(adc_h4)]
#[path = "adc/v4x7.rs"]
pub mod adc;
#[cfg(all(dac, not(ch32h4)))]
pub mod dac;
// H4's DAC uses per-channel registers (`R12BDHR1`, `EN1`, ...) instead of the
// V3 arrays, so it needs its own module.
#[cfg(dac_h4)]
#[path = "dac/h4.rs"]
pub mod dac;
#[cfg(awu)]
pub mod awu;
#[cfg(crc)]
pub mod crc;
pub mod exti;
pub mod gpio;
// H4 flags I2C as `version: v3`, so the existing V3 driver applies directly.
#[cfg(i2c)]
pub mod i2c;
#[cfg(i3c_v4x7)]
pub mod i3c;
#[cfg(rng)]
pub mod rng;
// `pioc` is a manual opt-in: the driver is useless without a firmware image,
// so it is not part of any chip feature.
#[cfg(all(peri_pioc, feature = "pioc"))]
pub mod pioc;
// Independent of `cfg(i2c)`: soft I2C exists precisely for chips or pins
// without an I2C peripheral.
#[cfg(feature = "soft-i2c")]
pub mod soft_i2c;
// The RTC block is the shared F1-style layout, but only CH32H4 currently has
// a PWR peripheral in the PAC for the `DBP` backup-domain write enable. V4x7
// has `PWR.CTLR.DBP` too, but a raw `RTCSEL` byte instead of the `Rtcsel`
// enum, so it needs its own branch before this gate can widen.
#[cfg(all(rtc, rcc_h4))]
pub mod rtc;
#[cfg(sdio_v3)]
pub mod sdio;
#[cfg(sdio_v4x7)]
#[path = "sdio/v4x7.rs"]
pub mod sdio;
pub mod signature;
#[cfg(spi)]
pub mod spi;
#[cfg(any(timer_x0, timer_v3, timer_h4, timer_v4x7))]
pub mod timer;
pub mod usart;
#[cfg(any(iwdg, wwdg))]
pub mod wdg;

/// Shared USB endpoint-buffer helpers (not a controller driver).
///
/// FS/HS controller drivers live in the modules below. Taxonomy (USBD vs
/// WCH-USBFS layouts vs USBHS) is documented in `ch32-data` `docs/usb_ip.md`.
pub mod usb;

/// WCH USBFS + OTG (`kind: otg` / `otg_v2`) — v2fs device layout + OTG regs.
#[cfg(otg)]
pub mod otg_fs;

/// H4's FS controller (`kind: usbfs` / `usbfs_h4`) and X035's `x0fs` block
/// (`kind: usb` / `x0fs`) are the same device core as `crate::otg_fs`, so
/// they reuse that driver. X035's register block is array-grouped; the
/// differences live in the `otg_fs::regs` adapter.
#[cfg(any(usbfs_h4, usb_x0fs))]
#[path = "otg_fs/mod.rs"]
pub mod usbfs;

/// WCH USBFS `l1fs` layout only (`kind: usb`, CH32L103). Sibling layouts
/// (`v1fs`/`v2fs`/`x0fs`) are not this module; see `ch32-data` `docs/usb_ip.md`.
/// H4's `kind: usbfs` and X035's `x0fs` use the OTG-v2 backend above, never
/// both at once.
#[cfg(usb_l1fs)]
pub mod usbfs;

/// Classic USB device-only (`kind: usbd` / EPR+BTABLE). Manual name: USBD.
#[cfg(usbd)]
pub mod usbd;

/// USB high-speed (`kind: usbhs`). H4 shares the `v4x7` register map; `v3`
/// is its own layout.
#[cfg(usbhs_v3)]
pub mod usbhs;
// H4's USBHS keeps the V4x7 device-block layout (same offsets, fieldsets and
// endpoint arrays), so the V4x7 driver serves both.
#[cfg(any(usbhs_v4x7, usbhs_h4))]
#[path = "usbhs/v4x7/mod.rs"]
pub mod usbhs;

/// USB 3.0 SuperSpeed device (`kind: usbss`, CH32H417) — RM §27.
#[cfg(usbss_h4)]
pub mod usbss;

// H4's USBPD register layout differs from V3 — gate out for now.
#[cfg(all(usbpd, not(ch32h4)))]
pub mod usbpd;

#[cfg(all(can, not(any(ch32h4, ch32v4))))]
pub mod can;
// H4's CAN block is the same bxCAN layout as V4x7 plus the shared 42-bank
// filter table, so the V4x7 driver covers both (see `can/v4x7.rs`).
#[cfg(any(can_v4x7, can_h4))]
#[path = "can/v4x7.rs"]
pub mod can;
// The V4x7 driver targets its own 10/100 `emac` register set; H4 has a
// separate gigabit block (`emac_h4`) with `PHY_CFGR` and RGMII. The V208 10M
// driver (`eth_10m`) needs `embassy-time` for TX completion and link polling,
// so it only exists with the `embassy` feature.
#[cfg(all(
    any(eth, emac),
    not(any(ch32v4, emac_h4)),
    any(not(eth_10m), feature = "embassy")
))]
pub mod eth;
#[cfg(emac_v4x7)]
#[path = "eth/v4x7.rs"]
pub mod eth;
#[cfg(emac_h4)]
#[path = "eth/h4.rs"]
pub mod eth;

#[cfg(flash)]
pub mod flash;

mod patches;

#[cfg(feature = "embassy")]
pub mod embassy;

// This must go last, so that it sees all the impl_foo! macros defined earlier.
pub(crate) mod _generated {
    #![allow(dead_code)]
    #![allow(unused_imports)]
    #![allow(non_snake_case)]
    #![allow(missing_docs)]

    include!(concat!(env!("OUT_DIR"), "/_generated.rs"));
}

pub use crate::_generated::interrupt;

pub struct Config {
    pub rcc: rcc::Config,
    pub dma_interrupt_priority: interrupt::Priority,
    /// Release the debug-interface pins for GPIO. Defaults to `false`.
    ///
    /// The debugger can only reattach after resetting into the system bootloader.
    #[cfg(afio)]
    pub release_swd_pins: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            rcc: Default::default(),
            dma_interrupt_priority: interrupt::Priority::P0,
            #[cfg(afio)]
            release_swd_pins: false,
        }
    }
}

/// Initialize the HAL with the provided configuration.
///
/// This returns the peripheral singletons that can be used for creating drivers.
///
/// This should only be called once at startup, otherwise it panics.
pub fn init(config: Config) -> Peripherals {
    // Do this first, so that it panics if user is calling `init` a second time
    // before doing anything important.
    let p = Peripherals::take();

    unsafe {
        rcc::init(config.rcc);
        delay::init();

        #[cfg(feature = "embassy")]
        embassy::init();
    }

    ::critical_section::with(|cs| unsafe {
        gpio::init(cs, true);
        // After `gpio::init`, because its AFIO reset pulse clears `SW_CFG`.
        #[cfg(afio)]
        if config.release_swd_pins {
            debug::release_swd_pins();
        }
        dma::init(cs, config.dma_interrupt_priority, true);
        #[cfg(feature = "exti")]
        exti::init(cs);
    });

    p
}

/// What [`init_secondary`] may touch on a core that does not own the chip.
///
/// The defaults only do what is safe while the boot core is running: read the
/// clock tree back, and turn on the GPIO port and DMA clocks (both are
/// write-1-to-enable bits the boot core already set). The AFIO reset and the
/// DMA interrupt enables are off because each changes state the boot core
/// relies on.
#[cfg(rcc_h4)]
pub struct SecondaryConfig {
    /// Crystal frequency, needed only when the boot core switched SYSCLK to
    /// HSE or to a PLL driven by it. `None` for HSI.
    pub hse: Option<time::Hertz>,
    /// Pulse the AFIO reset. That clears `GPIO_AFR` back to AF0, dropping
    /// every alternate function the boot core configured, so leave it off
    /// unless this core owns the whole pin mux.
    pub reset_afio: bool,
    /// Enable every DMA channel interrupt. On CH32H4 an interrupt above 31 is
    /// delivered to exactly one core, and enabling it assigns it to the core
    /// that did the enable, so this takes the DMA interrupts away from the
    /// boot core. Leave it off and let each transfer enable its own channel.
    pub enable_dma_irqs: bool,
    /// Priority stored for the DMA interrupts. Only matters for the channels
    /// this core actually enables.
    pub dma_interrupt_priority: interrupt::Priority,
}

#[cfg(rcc_h4)]
impl Default for SecondaryConfig {
    fn default() -> Self {
        Self {
            hse: None,
            reset_afio: false,
            enable_dma_irqs: false,
            dma_interrupt_priority: interrupt::Priority::P0,
        }
    }
}

/// Initialize the HAL on a core that does not own the clock tree.
///
/// For the second core of a dual-core chip: the boot core has already run
/// [`init`] and programmed the PLL, and doing that again here would switch
/// SYSCLK out from under it. This reads the RCC registers back into [`rcc::clocks`]
/// instead of writing them.
///
/// # Safety
///
/// The boot core must have finished [`init`] before this runs. The two cores
/// must not both use one peripheral. Each image is linked on its own, so each
/// has its own `Peripherals` singleton and this cannot tell that the other
/// core already took one.
#[cfg(rcc_h4)]
pub unsafe fn init_secondary(config: SecondaryConfig) -> Peripherals {
    let p = Peripherals::take();

    unsafe {
        rcc::refresh(config.hse);
        delay::init();

        #[cfg(feature = "embassy")]
        embassy::init();
    }

    ::critical_section::with(|cs| unsafe {
        gpio::init(cs, config.reset_afio);
        dma::init(cs, config.dma_interrupt_priority, config.enable_dma_irqs);
        #[cfg(feature = "exti")]
        exti::init(cs);
    });

    p
}

#[macro_export]
macro_rules! bind_interrupts {
    ($vis:vis struct $name:ident { $($irq:ident => $($handler:ty),*;)* }) => {
        #[derive(Copy, Clone)]
        $vis struct $name;

        $(
            #[allow(non_snake_case)]
            #[$crate::interrupt]
            unsafe fn $irq() {
                $(
                    <$handler as $crate::interrupt::typelevel::Handler<$crate::interrupt::typelevel::$irq>>::on_interrupt();
                )*
            }

            $(
                unsafe impl $crate::interrupt::typelevel::Binding<$crate::interrupt::typelevel::$irq, $handler> for $name {}
            )*
        )*
    };
}
